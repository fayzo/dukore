function black() {
   $('body').click(function() {
   $(this).attr('id','black');
    }); 
 } 

function white() {
 $('body').click(function() {
 $(this).attr('id','white');
  }); 
}