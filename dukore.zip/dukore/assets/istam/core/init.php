<?php
include('database/Db.php');
include('classes/User.php');
include('classes/Homepage.php');
include('classes/Comment.php');
include('classes/Follow.php');
include('classes/Message.php');
include('classes/Trending.php');
include('classes/Notification.php');

define('BASE_URL','http://localhost/dukore/');
// define('BASE_URL','http://localhost/tweet/');
define('NO_PROFILE_IMAGE_URL','assets/images/defaultprofileimage.png');
define('NO_COVER_IMAGE_URL','assets/images/defaultCoverImage.png');

/*
===========================================
         Notice
===========================================
# You are free to run the software as you wish
# You are free to help yourself study the source code and change to do what you wish
# You are free to help your neighbor copy and distribute the software
# You are free to help community create and distribute modified version as you wish

We promote Open Source Software by educating developers (Beginners)
use PHP Version 5.6.1 > 7.3.20  
===========================================
         For more information contact
=========================================== 
Kigali - Rwanda
Tel : (250)787384312 / (250)787384312
E-mail : shemafaysal@gmail.com

*/
?>